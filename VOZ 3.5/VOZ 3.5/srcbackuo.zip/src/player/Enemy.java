package player;

/*
 *
 *
 * @author YourSoulMatee
 */

public class Enemy extends Friend {

}
