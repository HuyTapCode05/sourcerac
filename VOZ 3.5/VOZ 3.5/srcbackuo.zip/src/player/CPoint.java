package player;

/*
 *
 *
 * @author YourSoulMatee
 */

public class CPoint {

    public byte limitPower;

    public byte speed;

    public long power;
    public long potential;

    public int stamina;
    public int maxStamina;

    public long hp;
    public long maxHp;
    public long oriHp;

    public long ki;
    public long maxKi;
    public long oriKi;

    public int dame;
    public int oriDame;

    public int def;
    public int oriDef;

    public int crit;
    public int oriCrit;

}
