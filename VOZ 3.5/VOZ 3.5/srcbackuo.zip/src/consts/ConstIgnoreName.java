package consts;

/*
 *
 *
 * @author YourSoulMatee
 */

public class ConstIgnoreName {

    public static final String[] IGNORE_NAME = {};

}
