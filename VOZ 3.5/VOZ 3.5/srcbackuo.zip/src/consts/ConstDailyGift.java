package consts;

public class ConstDailyGift {

    public static final byte NHAN_NGOC_MIEN_PHI = 0;
    public static final byte NHAN_BUA_MIEN_PHI = 1;

}
