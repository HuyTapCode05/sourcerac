package boss;

/*
 *
 *
 * @author YourSoulMatee
 */

public enum BossStatus {
    REST,
    RESPAWN,
    JOIN_MAP,
    CHAT_S,
    ACTIVE,
    DIE,
    CHAT_E,
    LEAVE_MAP,
    AFK
}
