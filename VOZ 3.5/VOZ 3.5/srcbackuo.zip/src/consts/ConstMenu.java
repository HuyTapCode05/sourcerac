package consts;

/**
 *
 * @author Admin
 */
public class ConstMenu {
    
    // index bà hạt mít
    public static final int MENU_PHA_LE = 251003;
    public static final int MENU_CHUYEN_HOA_TRANG_BI = 251004;
    public static final int MENU_PHA_LE_HOA_TRANG_BI = 251005;
    public static final int MENU_NANG_CAP_TRANG_BI = 251006;
    public static final int CHUC_NANG_BHM_KHAC = 251007;
    public static final int BUILD_DO_BHM = 251008;
     public static final int SHOP_BHM = 251009;

    //index đại thiên sứ

    public static final int MENU_SHOW = 0;
}
