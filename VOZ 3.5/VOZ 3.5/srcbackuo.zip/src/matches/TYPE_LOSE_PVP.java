package matches;

/*
 *
 *
 * @author YourSoulMatee
 */

public enum TYPE_LOSE_PVP {

    RUNS_AWAY,
    DEAD

}
