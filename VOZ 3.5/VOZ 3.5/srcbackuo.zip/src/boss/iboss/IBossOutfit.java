package boss.iboss;

/*
 *
 *
 * @author YourSoulMatee
 */

public interface IBossOutfit {

    short getHead();

    short getBody();

    short getLeg();

    short getFlagBag();

    byte getAura();

    byte getEffFront();
}
