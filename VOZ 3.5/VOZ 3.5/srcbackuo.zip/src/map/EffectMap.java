package map;

import lombok.Getter;
import lombok.Setter;

/**
 * @build by Soulmate
 */
@Setter
@Getter
public class EffectMap {
    private String key;
    private String value;
}
