package player;

/*
 *
 *
 * @author YourSoulMatee
 */

public class Location {

    public int x;
    public int y;

    public long lastTimeplayerMove;
}
