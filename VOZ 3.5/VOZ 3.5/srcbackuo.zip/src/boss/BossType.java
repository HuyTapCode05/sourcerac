package boss;

public enum BossType {

    YARDART,
    FINAL,
    SKILLSUMMONED,
    BROLY, 
    ANTROM,
    PLAYERAO,
    PHOBAN,
    PHOBANDT,
    PHOBANBDKB,
    PHOBANCDRD,
    PHOBANKGHD,
    TRUNGTHU_EVENT,
    HALLOWEEN_EVENT,
    CHRISTMAS_EVENT,
    HUNGVUONG_EVENT,
    TET_EVENT

}
