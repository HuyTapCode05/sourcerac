package consts;
/*
 *
 *
 * @author YourSoulMatee
 */

public class ConstSuperRank {

    public static final String TEXT_DUOI_HANG = "Không thể thi đấu dưới hạng mình";
    public static final String TEXT_CHINH_MINH = "Không thể thi đấu với chính mình";
    public static final String TEXT_TOP_100 = "Không thể thách đấu ở Top 100";
    public static final String TEXT_DOI_THU_CHO_THI_DAU = "Đối thủ đang chờ để lên võ đài";
    public static final String TEXT_DANG_CHO = "Đang chờ để thi đấu";
    public static final String TEXT_CHO_IT_PHUT = "Vui lòng chờ ít phút để lên võ đài";
    public static final String TEXT_DOI_THU_DANG_THI_DAU = "Đối thủ đang thi đấu";
    public static final String TEXT_DANG_THI_DAU = "Đang thi đấu";
    public static final String TEXT_KHONG_THE_THI_DAU_TREN_2_HANG = "Không thể thi đấu trên mình 2 hạng";
    public static final String TEXT_TOP_10 = "%1 vừa lên Top %2 Giải Siêu Hạng";
    public static final String TEXT_THANG = "";
    public static final String TEXT_THUA = "Thua rồi";
    public static final String TEXT_CLONE_THANG = "Đầu hàng chưa?";
    public static final String TEXT_CLONE_THUA = "Mạnh quá, ta chịu thua";
    public static final String TEXT_SAN_SANG_CHUA = "Sẵn sàng chưa?";
    public static final String TEXT_SAN_SANG = "OK";
    
}
