/*
 * Copyright by SOULMATE
 */

package player.badges;

public class Badges {

    public int idBadges = -1;
    public long lastTimeSendBadges;

}
